package nea.lox.patchloader;
import org.lsposed.lspd.service.*;
import java.util.*;
import org.lsposed.lspd.models.*;
import android.os.*;
import java.io.*;
import org.json.*;
import org.lsposed.lspatch.util.*;
import org.lsposed.lspd.hooker.*;
import de.robv.android.xposed.*;

public class LoxModuleService extends ILSPApplicationService.Stub
{

	public List<Module> modules;

	public LoxModuleService(String modulesConfigFilePath)
	{
		modules = new ArrayList<>();
		String packageName = LoxApplication.appInfo.packageName;
		ClassLoader appClassLoader = LoxApplication.appClassLoader;
		try
		{
			File moduleConfigFile = new File(modulesConfigFilePath);
			InputStream in = new FileInputStream(moduleConfigFile);
			byte[] bytes = new byte[in.available()];
			in.read(bytes);
			in.close();
			JSONArray data = new JSONArray(new String(bytes, "utf-8"));
			for (int i = 0; i < data.length(); i ++)
			{
				JSONObject modJson = data.getJSONObject(i);
				String modPackageName = modJson.getString("package");
				if (modJson.getBoolean("active"))
				{
					JSONArray scopeJson = modJson.getJSONArray("scope");
					if (packageName.equals(modPackageName))
					{
						XposedHelpers.findAndHookMethod("android.app.ContextImpl", appClassLoader, "checkMode", int.class, new PreferencesHook(false));
						XposedHelpers.findAndHookMethod("android.app.ContextImpl", appClassLoader, "getPreferencesDir", new PreferencesHook(true));
						scopeJson.put(0, packageName);
					}
					for (int j = 0; j < scopeJson.length(); j ++)
					{
						if (packageName.equals(scopeJson.getString(j)))
						{
							Module module = new Module();
							module.apkPath = modJson.getString("path");
							module.packageName = modPackageName;
							module.file = ModuleLoader.loadModule(module.apkPath);
							modules.add(module);
							break;
						}
					}
				}
			}
		}
		catch (Exception e)
		{}
	}

	@Override
	public List<Module> getLegacyModulesList() throws RemoteException
	{
		return modules;
	}

	@Override
	public List<Module> getModulesList() throws RemoteException
	{
		return modules;
	}

	@Override
	public String getPrefsPath(String packageName) throws RemoteException
	{
		String path = String.format("%s%s/xsp/", LoxApplication.loAppsPath, packageName);
		return path;
	}

	@Override
	public boolean isLogMuted() throws RemoteException
	{
		return false;
	}

	@Override
	public ParcelFileDescriptor requestInjectedManagerBinder(List<IBinder> p1) throws RemoteException
	{
		return null;
	}

	@Override
	public IBinder asBinder()
	{
		return this;
	}
}
