package nea.lox.patchloader;
import android.os.*;
import android.content.pm.*;
import android.content.*;
import java.lang.reflect.*;
import java.util.*;
import android.content.pm.PackageManager.*;
import java.io.*;
import org.json.*;

public class ProxyApplicationInfoCreator implements
Parcelable.Creator<ApplicationInfo>
{
	public Parcelable.Creator<ApplicationInfo> original;

	public static void proxy()
	{
		Field field = null;
		final Parcelable.Creator<ApplicationInfo> originalAppCreator = ApplicationInfo.CREATOR;
		ProxyApplicationInfoCreator proxiedAppCreator = new ProxyApplicationInfoCreator();
		proxiedAppCreator.original = originalAppCreator;
		try
		{
			field = ApplicationInfo.class.getField("CREATOR");
			field.setAccessible(true);
			field.set(null, proxiedAppCreator);
		}
		catch (Throwable ignore)
		{
		}
		try
		{
			field = Parcel.class.getDeclaredField("mCreators");
			field.setAccessible(true);
			Map<?, ?> mCreators = (Map<?, ?>) field.get(null);
			mCreators.clear();
			field = Parcel.class.getDeclaredField("sPairedCreators");
			field.setAccessible(true);
			Map<?, ?> sPairedCreators = (Map<?, ?>) field.get(null);
			sPairedCreators.clear();
		}
		catch (Throwable ignore)
		{
		}
	}

	@Override
	public ApplicationInfo createFromParcel(Parcel parcel)
	{
		ApplicationInfo info = original.createFromParcel(parcel);
		return getApplicationInfo(info);
	}

	@Override
	public ApplicationInfo[] newArray(int size)
	{
		return original.newArray(size);
	}

	public static ApplicationInfo getApplicationInfo(ApplicationInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						info.appComponentFactory = config.appComponentFactory;
					}
				}
				catch (Exception e)
				{}
			}
		}
		return info;
	}
}
