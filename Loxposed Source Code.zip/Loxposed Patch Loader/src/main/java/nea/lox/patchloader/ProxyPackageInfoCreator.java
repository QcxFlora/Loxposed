package nea.lox.patchloader;
import android.os.*;
import android.content.pm.*;
import android.content.*;
import java.lang.reflect.*;
import java.util.*;
import android.content.pm.PackageManager.*;
import java.io.*;
import org.json.*;
import de.robv.android.xposed.*;

public class ProxyPackageInfoCreator implements
Parcelable.Creator<PackageInfo>
{
	public Parcelable.Creator<PackageInfo> original;

	public static void proxy()
	{
		Field field = null;
		final Parcelable.Creator<PackageInfo> originalPackageCreator = PackageInfo.CREATOR;
		ProxyPackageInfoCreator proxiedPackageCreator = new ProxyPackageInfoCreator();
		proxiedPackageCreator.original = originalPackageCreator;
		try
		{
			field = PackageInfo.class.getField("CREATOR");
			field.setAccessible(true);
			field.set(null, proxiedPackageCreator);
		}
		catch (Throwable ignore)
		{
		}
		try
		{
			field = Parcel.class.getDeclaredField("mCreators");
			field.setAccessible(true);
			Map<?, ?> mCreators = (Map<?, ?>) field.get(null);
			mCreators.clear();
			field = Parcel.class.getDeclaredField("sPairedCreators");
			field.setAccessible(true);
			Map<?, ?> sPairedCreators = (Map<?, ?>) field.get(null);
			sPairedCreators.clear();
		}
		catch (Throwable ignore)
		{
		}
	}

	@Override
	public PackageInfo createFromParcel(Parcel parcel)
	{
		PackageInfo info = original.createFromParcel(parcel);
		return getPackageInfo(info);
	}

	@Override
	public PackageInfo[] newArray(int size)
	{
		return original.newArray(size);
	}

	public static PackageInfo getPackageInfo(PackageInfo info)
	{
		if (info != null)
		{
			String packageName = info.packageName;
			if (packageName != null)
			{
				try
				{
					PatchConfig config = LoxApplication.getPatchConfig(packageName);
					if (config != null)
					{
						if (info.signatures != null) info.signatures = config.signatures;
						if (info.signingInfo != null)
						{
							Object details = XposedHelpers.getObjectField(info.signingInfo, "mSigningDetails");
							XposedHelpers.setObjectField(details, "mSignatures", config.signatures);
						}
						info.applicationInfo.appComponentFactory = config.appComponentFactory;
					}
				}
				catch (Exception e)
				{}
			}
		}
		return info;
	}
}
