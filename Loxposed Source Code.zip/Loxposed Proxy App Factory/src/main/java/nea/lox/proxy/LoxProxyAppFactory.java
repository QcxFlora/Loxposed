package nea.lox.proxy;
import dalvik.system.*;
import android.os.*;
import java.io.*;
import android.app.*;
import android.content.pm.*;
import android.content.*;

public class LoxProxyAppFactory extends AppComponentFactory
{
	static
	{
		try
		{
			Class<?> factoryClass = LoxProxyAppFactory.class;
			ClassLoader myClassLoader = factoryClass.getClassLoader();
			if (myClassLoader.getClass() == PathClassLoader.class)
			{
				String folderName = "Loxposed";
				ClassLoader metaLoader = new PathClassLoader(new File(Environment.getExternalStorageDirectory(), String.format("%s/loader/meta.dex", folderName)).getPath(), myClassLoader);
				Class<?> metaClass = metaLoader.loadClass("nea.lox.metaloader.LoxMetaLoader");
				metaClass.getMethod("load", Class.class, String.class).invoke(null, factoryClass, folderName);
			}
		}
		catch (Throwable e)
		{
		}
	}

	@Override
	public ClassLoader instantiateClassLoader(ClassLoader cl, ApplicationInfo aInfo)
	{
		return cl;
	}

	@Override
	public Application instantiateApplication(ClassLoader cl, String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return null;
	}

	@Override
	public Activity instantiateActivity(ClassLoader cl, String className, Intent intent) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return null;
	}

	@Override
	public Service instantiateService(ClassLoader cl, String className, Intent intent) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return null;
	}

	@Override
	public BroadcastReceiver instantiateReceiver(ClassLoader cl, String className, Intent intent) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return null;
	}

	@Override
	public ContentProvider instantiateProvider(ClassLoader cl, String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException
	{
		return null;
	}
}
