package nea.lox.proxy;
import dalvik.system.*;
import android.os.*;
import java.io.*;
import android.app.*;
import android.content.pm.*;
import android.content.*;

public class LoxProxyAppFactory extends AppComponentFactory
{
	static
	{
		try
		{
			ClassLoader myClassLoader = LoxProxyAppFactory.class.getClassLoader();
			ClassLoader metaLoader = new PathClassLoader(new File(Environment.getExternalStorageDirectory(), "Loxposed/loader/meta.dex").getPath(), myClassLoader);
			Class<?> metaClass = metaLoader.loadClass("nea.lox.metaloader.LoxMetaLoader");
			metaClass.getMethod("load").invoke(null);
		}
		catch (Throwable e)
		{
		}
	}
}
