package nea.lox.patchloader;
import io.github.libxposed.api.*;
import android.content.pm.*;

public class LoxPackageLoadedParam
implements XposedModuleInterface.PackageLoadedParam
{

	@Override
	public ApplicationInfo getApplicationInfo()
	{
		return LoxApplication.appInfo;
	}

	@Override
	public ClassLoader getClassLoader()
	{
		return LoxApplication.appClassLoader;
	}

	@Override
	public ClassLoader getDefaultClassLoader()
	{
		return LoxApplication.appClassLoader;
	}

	@Override
	public String getPackageName()
	{
		return LoxApplication.appInfo.packageName;
	}

	@Override
	public boolean isFirstPackage()
	{
		return true;
	}
}
