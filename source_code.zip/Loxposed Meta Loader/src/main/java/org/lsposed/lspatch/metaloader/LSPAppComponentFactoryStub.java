package org.lsposed.lspatch.metaloader;

public class LSPAppComponentFactoryStub
{
	public static byte[] dex;
}
